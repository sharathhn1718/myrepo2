const express = require("express");
const axios = require("axios");
const moment = require("moment");

const app = express();

app.use(express.static("public"));

app.get("/worklog", (req, res) => {
  const access_token = "";
  const user_name = req.query["user-name"];
  const start_date = moment(req.query["start-date"]).format("YYYY-MM-DD");
  const end_date = moment(req.query["end-date"]).format("YYYY-MM-DD");

  const url = "https://jira.com/rest/api/2/search";

  const query_params = {
    params: {
      jql: `worklogAuthor = "${user_name}" and worklogDate >= '${start_date}' and worklogDate <= '${end_date}'`,
      maxResults: 1000,
      fields: "worklog,summary",
    },
    headers: {
      Authorization: `Bearer ${access_token}`,
    },
  };

  axios
    .get(url, query_params)
    .then(response => {
      let issuesByDate = {};
      let totalWorkHoursByDate = {};

      response.data.issues.forEach(issue => {
        issue.fields.worklog.worklogs.forEach(worklog => {
          const worklogStarted = moment(worklog.started);
          if (
            worklog.author.name === user_name &&
            worklogStarted.isBetween(start_date, end_date, null, "[]")
          ) {
            const date = worklogStarted.format("YYYY-MM-DD");
            const time_spent_seconds = worklog.timeSpentSeconds;
            const time_spent_hours = time_spent_seconds / 3600;

            if (!issuesByDate[date]) {
              issuesByDate[date] = [];
            }

            issuesByDate[date].push({
              name: issue.fields.summary,
              link: `https://jira.mrs-electronic.com/browse/${issue.key}`,
              hours: time_spent_hours,
            });

            totalWorkHoursByDate[date] = totalWorkHoursByDate[date] || 0;
            totalWorkHoursByDate[date] += time_spent_hours;
          }
        });
      });

      // Add missing dates with no work logs
      const currentDate = moment(start_date);
      const endDate = moment(end_date);
      while (currentDate.isSameOrBefore(endDate)) {
        const date = currentDate.format("YYYY-MM-DD");
        if (!issuesByDate[date]) {
          issuesByDate[date] = [];
          totalWorkHoursByDate[date] = 0;
        }
        currentDate.add(1, "day");
      }

      res.send({ issuesByDate, totalWorkHoursByDate });
    })
    .catch(error => res.status(500).send(error));
});

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/index.html");
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
